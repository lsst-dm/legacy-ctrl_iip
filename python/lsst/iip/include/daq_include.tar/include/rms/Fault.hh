 
#ifndef RMS_FAULT
#define RMS_FAULT

namespace RMS  {
  
  enum Fault{ OK=0, INV=1, TMO=2, LNK=3};
    
}

#endif

