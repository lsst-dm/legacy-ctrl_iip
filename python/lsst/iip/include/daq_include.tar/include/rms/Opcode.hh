 
#ifndef RMS_OPCODE
#define RMS_OPCODE

namespace RMS  
{
  enum Opcode {GET = 0, PUT = 1, BIS = 2, BIC = 3};
}

#endif

