#ifndef SSU_SVT_H
#define SSU_SVT_H

#define DAQ_RELEASE_TABLE_NUM   1
#define DAQ_RELEASE_TABLE      (1 << DAQ_RELEASE_TABLE_NUM)

#endif
